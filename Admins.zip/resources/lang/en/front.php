<?php
return[
    'home'=>'Homepage',
    'news'=>'Egypt News ',
    'about'=>' About ',
    'contact'=>' Contact ',
    'register'=>'Register ',
    'login'=>'Login',
    'rights'=>'All right reserved to Ehm-eg.com ',
    'login'=>'Admin Login',
    'phone'=>'Phone Number',
    'password'=>'Secret Number',
    'countryCodeName'=>'Country Code Name',
    'youtube'=>' Kindly Enter the required Link',
    'url'=>'Required Link ',
    'analysis'=>'Analysis',
    'youtube_analytics'=>'Youtube Analytics...',
    'link'=>'Required Link : ',
    'subNumber'=>'number of subscribers : ',
    'count' =>'View Count : ',
    'total' =>'  Total videos : ',
    'ch'=>'Youtube Channel Analytics '
];
