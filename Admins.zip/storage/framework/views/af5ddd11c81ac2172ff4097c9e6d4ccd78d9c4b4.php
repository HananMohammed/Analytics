<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset_public('css/homepage.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="jumbotron">
           <h1 class="display-4">Analytics </h1>
           <p class="lead text-dark">
               a free web  Site for analytics still under deployment.
           </p>
           <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admins\resources\views/components/front/hompage.blade.php ENDPATH**/ ?>