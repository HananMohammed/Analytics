<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center" >
            <div class="col-sm-12 pb-5 text-light url-form">
                <h5 class="sub"> <?php echo app('translator')->get('front.youtube'); ?></h5>
            </div>
            <div class="col-sm-12 pt-3 pb-3 url-form">
                <form action="<?php echo e(route('youtube',app()->getLocale())); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="url" name="url" placeholder="<?php echo app('translator')->get('front.url'); ?>">
                     <?php if(isset($wrongLink)): ?>
                       <br>
                        <span class="error" style="color: red;"><?php echo e($wrongLink); ?></span>
                    <br>
                    <?php endif; ?>

                    <input type="submit" class="btn btn-success mt-5 ml-5 btn-subscribe" value="get Data">
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admins\resources\views/components/youtube-subscriber.blade.php ENDPATH**/ ?>